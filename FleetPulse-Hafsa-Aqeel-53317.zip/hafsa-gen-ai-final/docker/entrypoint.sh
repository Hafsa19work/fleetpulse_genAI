#!/bin/sh
# FleetPulse container entrypoint.
#
#   api        seed if needed, then serve the API + dashboard  (default)
#   simulator  wait for the API, then drive the fleet
#   test       run the AI-generated pytest suite and exit
#   seed       (re)build the demo dataset and exit
#   <anything else> executed verbatim, e.g. `docker compose run api sh`
set -e

COMMAND="${1:-api}"
API_URL="${FLEETPULSE_API_URL:-http://api:8000}"

wait_for_api() {
    echo "waiting for ${API_URL} ..."
    # The API needs to be up before the simulator can post to it. Bounded so a
    # broken API surfaces as a clear failure rather than a container that hangs.
    i=0
    while [ "$i" -lt 60 ]; do
        if curl -fsS "${API_URL}/api/health" >/dev/null 2>&1; then
            echo "API is up"
            return 0
        fi
        i=$((i + 1))
        sleep 1
    done
    echo "ERROR: ${API_URL} did not become healthy within 60s" >&2
    return 1
}

case "$COMMAND" in
    api)
        # Idempotent: seeds only an empty database, so restarting the container
        # never wipes the alerts raised during a demo.
        python -m app.seed
        echo "starting FleetPulse API + dashboard on :8000"
        exec uvicorn app.main:app --host 0.0.0.0 --port 8000
        ;;

    seed)
        shift
        exec python -m app.seed "$@"
        ;;

    simulator)
        shift
        wait_for_api
        exec python -m app.simulate --api "${API_URL}" "$@"
        ;;

    test)
        shift
        # Tests use their own in-memory database; the mounted volume is untouched.
        exec python -m pytest "$@"
        ;;

    *)
        exec "$@"
        ;;
esac
